import { Ionicons } from "@expo/vector-icons";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View } from "react-native";

import { MovieProvider } from "./src/context/MovieContext";
import { ThemeProvider, useTheme } from "./src/context/ThemeContext";
import Favorites from "./src/screens/Favorites";
import Home from "./src/screens/Home";
import MovieDetail from "./src/screens/MovieDetail";
import Profile from "./src/screens/Profile";

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

function TabsNavigator({ theme }) {
  return (
    <Tab.Navigator
      initialRouteName="Home"
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarIcon: ({ color, size }) => {
          let iconName;
          if (route.name === "Home") iconName = "home";
          else if (route.name === "Favorites") iconName = "heart";
          else if (route.name === "Profile") iconName = "settings";
          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: "#e50914",
        tabBarInactiveTintColor: "#888",
        tabBarStyle: { backgroundColor: theme.surface, borderTopColor: theme.border, borderTopWidth: 1 },
      })}
    >
      <Tab.Screen name="Home" component={Home} />
      <Tab.Screen name="Favorites" component={Favorites} />
      <Tab.Screen name="Profile" component={Profile} />
    </Tab.Navigator>
  );
}

function TabsWrapper(props) {
  return <TabsNavigator theme={props.theme} />;
}

function AppContent() {
  const { theme } = useTheme();

  return (
    <View style={{ flex: 1, backgroundColor: theme.background }}>
      <Stack.Navigator
        screenOptions={{
          headerShown: false,
        }}
      >
        <Stack.Screen name="Tabs">
          {() => <TabsWrapper theme={theme} />}
        </Stack.Screen>
        <Stack.Screen name="MovieDetail" component={MovieDetail} />
      </Stack.Navigator>
    </View>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <MovieProvider>
        <NavigationContainer>
          <AppContent />
        </NavigationContainer>
      </MovieProvider>
    </ThemeProvider>
  );
}
