export const TMDB_API_KEY = "987a7fa64785a7fd0dd7e200fe20b852";
export const TMDB_BASE_URL = "https://api.themoviedb.org/3";
export const TMDB_IMAGE_BASE = "https://image.tmdb.org/t/p/w500";

