import AsyncStorage from "@react-native-async-storage/async-storage";
import { createContext, useContext, useEffect, useState } from "react";

const ThemeContext = createContext();
export const useTheme = () => useContext(ThemeContext);

export const themes = {
  dark: {
    background: "#121212",
    surface: "#1c1c1c",
    text: "#fff",
    textSecondary: "#888",
    primary: "#e50914",
    border: "#2a2a2a",
  },
  light: {
    background: "#f5f5f5",
    surface: "#ffffff",
    text: "#000",
    textSecondary: "#666",
    primary: "#e50914",
    border: "#e0e0e0",
  },
};

export const ThemeProvider = ({ children }) => {
  const [isDarkMode, setIsDarkMode] = useState(true);

  useEffect(() => {
    loadTheme();
  }, []);

  const loadTheme = async () => {
    try {
      const savedTheme = await AsyncStorage.getItem("@theme");
      if (savedTheme) setIsDarkMode(JSON.parse(savedTheme));
    } catch (e) {
      console.warn("Error loading theme:", e);
    }
  };

  const toggleTheme = async () => {
    try {
      const newValue = !isDarkMode;
      setIsDarkMode(newValue);
      await AsyncStorage.setItem("@theme", JSON.stringify(newValue));
    } catch (e) {
      console.warn("Error saving theme:", e);
    }
  };

  const theme = isDarkMode ? themes.dark : themes.light;

  return (
    <ThemeContext.Provider value={{ isDarkMode, toggleTheme, theme }}>
      {children}
    </ThemeContext.Provider>
  );
};
