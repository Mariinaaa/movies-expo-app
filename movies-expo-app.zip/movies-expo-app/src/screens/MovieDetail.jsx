import { Ionicons } from "@expo/vector-icons";
import { Image, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useMovies } from "../context/MovieContext";
import { useTheme } from "../context/ThemeContext";

const TMDB_IMAGE_BASE = "https://image.tmdb.org/t/p/w500";

export default function MovieDetail({ route, navigation }) {
  const { movie } = route.params;
  const { theme } = useTheme();
  const { isFavorite, toggleFavorite } = useMovies();

  const year = movie.release_date ? movie.release_date.split("-")[0] : "N/A";
  const rating = movie.vote_average ? movie.vote_average.toFixed(1) : "N/A";

  const getRatingColor = (value) => {
    const r = parseFloat(value);
    if (isNaN(r)) return '#FFD700';
    if (r >= 7) return '#4CD964';
    if (r >= 5) return '#FFC107';
    return '#EF5350';
  };

  return (
    <ScrollView style={[styles.container, { backgroundColor: theme.background }]}>
      {/* Header con botón atrás */}
      <View style={[styles.header, { backgroundColor: theme.surface }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={28} color={theme.primary} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: theme.text }]}>Detalles de Película</Text>
        <TouchableOpacity onPress={() => toggleFavorite(movie)}>
          <Ionicons
            name={isFavorite(movie.id) ? "heart" : "heart-outline"}
            size={28}
            color={isFavorite(movie.id) ? "#ff6b6b" : theme.primary}
          />
        </TouchableOpacity>
      </View>

      {/* Imagen Póster */}
      {movie.poster_path && (
        <View style={styles.posterContainer}>
          <Image
            style={styles.posterImage}
            source={{ uri: TMDB_IMAGE_BASE + movie.poster_path }}
            alt={movie.title}
          />
        </View>
      )}

      {/* Información Principal */}
      <View style={[styles.infoSection, { backgroundColor: theme.surface, borderBottomColor: theme.border }]}>
        <Text style={[styles.title, { color: theme.text }]}>{movie.title}</Text>
        
        <View style={styles.metaRow}>
          <View style={styles.metaItem}>
            <Ionicons name="calendar-outline" size={16} color={theme.primary} />
            <Text style={[styles.metaText, { color: theme.textSecondary }]}>{year}</Text>
          </View>
          
          <View style={styles.metaItem}>
            <Ionicons name="star" size={16} color={getRatingColor(rating)} />
            <Text style={[styles.metaText, { color: theme.text }]}>{rating}/10</Text>
          </View>

          <View style={styles.metaItem}>
            <Ionicons name="eye-outline" size={16} color={theme.primary} />
            <Text style={[styles.metaText, { color: theme.textSecondary }]}>
              {movie.popularity ? movie.popularity.toFixed(0) : "N/A"}
            </Text>
          </View>
        </View>
      </View>

      {/* Sinopsis */}
      <View style={[styles.section, { backgroundColor: theme.surface, marginTop: 12 }]}>
        <Text style={[styles.sectionTitle, { color: theme.text }]}>Sinopsis</Text>
        <Text style={[styles.synopsis, { color: theme.textSecondary }]}>
          {movie.overview || "No hay sinopsis disponible"}
        </Text>
      </View>

      {/* Estadísticas */}
      <View style={[styles.section, { backgroundColor: theme.surface, marginTop: 12 }]}>
        <Text style={[styles.sectionTitle, { color: theme.text }]}>Estadísticas</Text>
        
        <View style={[styles.statRow, { borderBottomColor: theme.border }]}>
          <Text style={[styles.statLabel, { color: theme.textSecondary }]}>Popularidad:</Text>
          <Text style={[styles.statValue, { color: theme.primary }]}>
            {movie.popularity ? movie.popularity.toFixed(2) : "N/A"}
          </Text>
        </View>

        <View style={[styles.statRow, { borderBottomColor: theme.border }]}>
          <Text style={[styles.statLabel, { color: theme.textSecondary }]}>Votos:</Text>
          <Text style={[styles.statValue, { color: theme.primary }]}>
            {movie.vote_count || "N/A"}
          </Text>
        </View>

        <View style={styles.statRow}>
          <Text style={[styles.statLabel, { color: theme.textSecondary }]}>Idioma Original:</Text>
          <Text style={[styles.statValue, { color: theme.primary }]}>
            {movie.original_language?.toUpperCase() || "N/A"}
          </Text>
        </View>
      </View>

      {/* Footer espaciado */}
      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "700",
  },
  posterContainer: {
    alignItems: "center",
    paddingVertical: 20,
  },
  posterImage: {
    width: 200,
    height: 300,
    borderRadius: 12,
    resizeMode: "cover",
  },
  infoSection: {
    paddingHorizontal: 16,
    paddingVertical: 16,
    marginHorizontal: 8,
    borderRadius: 12,
    borderBottomWidth: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: "700",
    marginBottom: 12,
  },
  metaRow: {
    flexDirection: "row",
    justifyContent: "space-around",
  },
  metaItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  metaText: {
    fontSize: 14,
    fontWeight: "600",
  },
  section: {
    marginHorizontal: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    marginBottom: 12,
  },
  synopsis: {
    fontSize: 14,
    lineHeight: 22,
  },
  statRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 10,
    borderBottomWidth: 1,
  },
  statLabel: {
    fontSize: 14,
  },
  statValue: {
    fontSize: 14,
    fontWeight: "600",
  },
});
