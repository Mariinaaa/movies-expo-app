import axios from "axios";
import { useEffect, useState } from "react";
import { ActivityIndicator, Dimensions, FlatList, SafeAreaView, StyleSheet, Text, TextInput, View } from "react-native";
import { TMDB_API_KEY, TMDB_BASE_URL } from "../../tmdbConfig";
import MovieCard from "../components/MovieCard";
import NavBar from "../components/NavBar";
import { useTheme } from "../context/ThemeContext";


export default function Home({ navigation }) {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [columns, setColumns] = useState(2);
  const { theme } = useTheme();

  useEffect(() => {
    const updateColumns = ({ window }) => {
      const width = window.width;
      if (width < 500) setColumns(2);
      else if (width < 800) setColumns(3);
      else if (width < 1100) setColumns(4);
      else setColumns(5);
    };
    updateColumns({ window: Dimensions.get('window') });
    const sub = Dimensions.addEventListener?.('change', updateColumns);
    return () => {
      if (sub?.remove) sub.remove();
    };
  }, []);

  const fetchPopular = async () => {
    setLoading(true);
    try {
      const res = await axios.get(`${TMDB_BASE_URL}/movie/popular?api_key=${TMDB_API_KEY}&language=en-US&page=1`);
      setMovies(res.data.results);
    } catch(e){ console.warn(e); }
    setLoading(false);
  };

  const searchMovies = async (query) => {
    if(!query){ fetchPopular(); return; }
    setLoading(true);
    try {
      const res = await axios.get(`${TMDB_BASE_URL}/search/movie?api_key=${TMDB_API_KEY}&language=en-US&query=${query}`);
      setMovies(res.data.results);
    } catch(e){ console.warn(e); }
    setLoading(false);
  };

  useEffect(() => { fetchPopular(); }, []);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
      <NavBar />
      <Text style={[styles.header, { color: theme.text }]}>Movie Explorer</Text>
      <TextInput
        placeholder="Buscar películas..."
        placeholderTextColor={theme.textSecondary}
        value={searchQuery}
        onChangeText={text => { setSearchQuery(text); searchMovies(text); }}
        style={[styles.search, { backgroundColor: theme.surface, color: theme.text, borderColor: theme.border }]}
      />

      {loading ? (
        <ActivityIndicator size="large" color="#e50914" style={{ marginTop: 40 }} />
      ) : movies.length === 0 ? (
        <View style={styles.empty}><Text style={{ color: theme.text }}>No hay resultados</Text></View>
      ) : (
        <FlatList
          key={columns}
          data={movies}
          keyExtractor={item => String(item.id)}
          renderItem={({ item }) => (
            <MovieCard movie={item} onPress={(m) => navigation.navigate('MovieDetail', { movie: m })} />
          )}
          numColumns={columns}
          contentContainerStyle={styles.list}
          columnWrapperStyle={styles.row}
          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 6,
  },
  header: {
    fontSize: 24,
    fontWeight: "700",
    marginVertical: 12,
    textAlign: "center",
  },
  search: {
    borderRadius: 8,
    padding: 10,
    marginBottom: 12,
    borderWidth: 1,
  },
  list: {
    paddingHorizontal: 6,
    paddingBottom: 24,
  },
  row: {
    justifyContent: 'space-between',
    paddingHorizontal: 2,
  },
  empty: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 40,
  },
});
