import { useEffect, useState } from "react";
import { Dimensions, FlatList, SafeAreaView, StyleSheet, Text, View } from "react-native";
import MovieCard from "../components/MovieCard";
import NavBar from "../components/NavBar";
import { useMovies } from "../context/MovieContext";
import { useTheme } from "../context/ThemeContext";

export default function Favorites({ navigation }) {
  const { favorites } = useMovies();
  const { theme } = useTheme();
  const [columns, setColumns] = useState(2);

  useEffect(() => {
    const updateColumns = ({ window }) => {
      const width = window.width;
      if (width < 500) setColumns(2);
      else if (width < 800) setColumns(3);
      else if (width < 1100) setColumns(4);
      else setColumns(5);
    };
    updateColumns({ window: Dimensions.get('window') });
    const sub = Dimensions.addEventListener?.('change', updateColumns);
    return () => {
      if (sub?.remove) sub.remove();
    };
  }, []);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
      <NavBar />
      <View style={[styles.header, { borderBottomColor: theme.border }]}><Text style={[styles.title, { color: theme.text }]}>Favoritos</Text></View>
      <View style={{ paddingHorizontal: 12, paddingVertical: 2 }}>
        <Text style={{ color: theme.textSecondary, fontSize: 12 }}>Favoritos cargados: {favorites.length}</Text>
      </View>
      {favorites.length === 0 ? 
        <View style={styles.empty}><Text style={[styles.emptyText, { color: theme.text }]}>No tienes favoritos aún</Text></View> :
        <FlatList
          key={columns}
          data={favorites}
          keyExtractor={item => String(item.id)}
          renderItem={({item}) => (
            <MovieCard movie={item} onPress={(m) => navigation.navigate('MovieDetail', { movie: m })} />
          )}
          numColumns={columns}
          contentContainerStyle={styles.list}
          columnWrapperStyle={styles.row}
        />
      }
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header:{padding:12,alignItems:"center",borderBottomWidth:1},
  title:{fontSize:20,fontWeight:"700"},
  list:{paddingHorizontal:8,paddingBottom:24},
  row:{
    justifyContent: 'space-evenly',
    paddingHorizontal: 4,
  },
  empty:{flex:1,alignItems:"center",justifyContent:"center",marginTop:40},
  emptyText:{fontWeight:"600"}
});
