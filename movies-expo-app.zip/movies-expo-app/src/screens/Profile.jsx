import { Ionicons } from "@expo/vector-icons";
import { ScrollView, StyleSheet, Switch, Text, View } from "react-native";
import NavBar from "../components/NavBar";
import { useMovies } from "../context/MovieContext";
import { useTheme } from "../context/ThemeContext";

export default function Profile() {
  const { favorites } = useMovies();
  const { isDarkMode, toggleTheme, theme } = useTheme();

  return (
    <ScrollView style={[styles.container, { backgroundColor: theme.background }]}>
      <NavBar />
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: theme.primary }]}>
        <Ionicons name="person-circle" size={80} color={theme.primary} />
        <Text style={[styles.title, { color: theme.text }]}>Mi Perfil</Text>
      </View>

      {/* Estadísticas */}
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: theme.text }]}>📊 Estadísticas</Text>
        <View style={[styles.statsBox, { backgroundColor: theme.surface }]}>
          <View style={styles.statItem}>
            <Ionicons name="heart" size={32} color={theme.primary} />
            <View style={styles.statContent}>
              <Text style={[styles.statLabel, { color: theme.textSecondary }]}>Películas Favoritas</Text>
              <Text style={[styles.statValue, { color: theme.primary }]}>{favorites.length}</Text>
            </View>
          </View>
        </View>
      </View>

      {/* Tema */}
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: theme.text }]}>🎨 Tema</Text>
        <View style={[styles.settingRow, { backgroundColor: theme.surface }]}>
          <View style={styles.settingLeft}>
            <Ionicons name={isDarkMode ? "moon" : "sunny"} size={24} color={theme.primary} />
            <View>
              <Text style={[styles.settingTitle, { color: theme.text }]}>Tema Oscuro</Text>
              <Text style={[styles.settingDescription, { color: theme.textSecondary }]}>
                {isDarkMode ? "Activado" : "Desactivado"}
              </Text>
            </View>
          </View>
          <Switch
            value={isDarkMode}
            onValueChange={toggleTheme}
            trackColor={{ false: "#ccc", true: theme.primary }}
            thumbColor="#fff"
          />
        </View>
      </View>

      {/* Información */}
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: theme.text }]}>ℹ️ Información de la App</Text>
        <View style={[styles.infoBox, { backgroundColor: theme.surface }]}>
          <View style={[styles.infoRow, { borderBottomColor: theme.border }]}>
            <Text style={[styles.infoLabel, { color: theme.textSecondary }]}>Versión:</Text>
            <Text style={[styles.infoValue, { color: theme.primary }]}>1.0.0</Text>
          </View>
          <View style={[styles.infoRow, { borderBottomColor: theme.border }]}>
            <Text style={[styles.infoLabel, { color: theme.textSecondary }]}>Plataforma:</Text>
            <Text style={[styles.infoValue, { color: theme.primary }]}>React Native + Expo</Text>
          </View>
          <View style={[styles.infoRow, { borderBottomColor: theme.border }]}>
            <Text style={[styles.infoLabel, { color: theme.textSecondary }]}>API:</Text>
            <Text style={[styles.infoValue, { color: theme.primary }]}>The Movie Database (TMDB)</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={[styles.infoLabel, { color: theme.textSecondary }]}>Almacenamiento:</Text>
            <Text style={[styles.infoValue, { color: theme.primary }]}>AsyncStorage Local</Text>
          </View>
        </View>
      </View>

      {/* Footer */}
      <View style={[styles.footer, { borderTopColor: theme.border }]}>
        <Text style={[styles.footerText, { color: theme.textSecondary }]}>Movie Explorer © 2025</Text>
        <Text style={[styles.footerSubtext, { color: theme.textSecondary }]}>Powered by TMDB API</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    alignItems: "center",
    paddingVertical: 30,
    borderBottomWidth: 1,
    marginBottom: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: "700",
    marginTop: 12,
  },
  section: {
    paddingHorizontal: 16,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    marginBottom: 12,
  },
  statsBox: {
    borderRadius: 12,
    padding: 16,
  },
  statItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 16,
  },
  statContent: {
    flex: 1,
  },
  statLabel: {
    fontSize: 12,
    marginBottom: 4,
  },
  statValue: {
    fontSize: 24,
    fontWeight: "700",
  },
  settingRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 14,
    paddingVertical: 14,
    borderRadius: 10,
  },
  settingLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    flex: 1,
  },
  settingTitle: {
    fontSize: 14,
    fontWeight: "700",
  },
  settingDescription: {
    fontSize: 12,
    marginTop: 2,
  },
  infoBox: {
    borderRadius: 10,
    padding: 14,
  },
  infoRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 10,
    borderBottomWidth: 1,
  },
  infoLabel: {
    fontSize: 12,
  },
  infoValue: {
    fontSize: 12,
    fontWeight: "600",
  },
  footer: {
    alignItems: "center",
    paddingVertical: 24,
    borderTopWidth: 1,
    marginTop: 20,
  },
  footerText: {
    fontSize: 12,
  },
  footerSubtext: {
    fontSize: 10,
    marginTop: 4,
  },
});


