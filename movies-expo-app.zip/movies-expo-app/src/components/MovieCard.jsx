import { Ionicons } from "@expo/vector-icons";
import { ImageBackground, Platform, Pressable, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useMovies } from "../context/MovieContext";

const TMDB_IMAGE_BASE = "https://image.tmdb.org/t/p/w500";

export default function MovieCard({ movie, onPress }) {
  const { toggleFavorite, isFavorite } = useMovies();

  const year = movie.release_date ? movie.release_date.split("-")[0] : "N/A";
  const rating = movie.vote_average ? movie.vote_average.toFixed(1) : "N/A";

  const getRatingColor = (value) => {
    const r = parseFloat(value);
    if (isNaN(r)) return '#FFD700';
    if (r >= 7) return '#4CD964';
    if (r >= 5) return '#FFC107';
    return '#EF5350';
  };

  return (
    <Pressable style={styles.card} onPress={() => onPress?.(movie)} android_ripple={{ color: 'rgba(255,255,255,0.04)' }}>
      {movie.poster_path ? (
        <ImageBackground
          source={{ uri: TMDB_IMAGE_BASE + movie.poster_path }}
          style={styles.image}
          imageStyle={styles.imageStyle}
        >
          <View style={styles.overlay}>
            <View style={styles.infoLeft}>
              <Text style={styles.title} numberOfLines={1}>{movie.title}</Text>
              <Text style={styles.year}>{year}</Text>
            </View>
            <View style={styles.rating}>
              <Ionicons name="star" size={14} color={getRatingColor(rating)} />
              <Text style={styles.ratingText}>{rating}</Text>
            </View>
          </View>
        </ImageBackground>
      ) : (
        <View style={[styles.image, styles.imagePlaceholder]}>
          <View style={styles.placeholder}>
            <Ionicons name="image-outline" size={42} color="#666" />
            <Text style={styles.placeholderText}>No Image</Text>
          </View>
          <View style={styles.overlay}>
            <View style={styles.infoLeft}>
              <Text style={styles.title} numberOfLines={1}>{movie.title}</Text>
              <Text style={styles.year}>{year}</Text>
            </View>
            <View style={styles.rating}>
              <Ionicons name="star" size={14} color={getRatingColor(rating)} />
              <Text style={styles.ratingText}>{rating}</Text>
            </View>
          </View>
        </View>
      )}
      <TouchableOpacity
        style={styles.favoriteButton}
        onPress={(e) => { e?.stopPropagation?.(); toggleFavorite(movie); }}
      >
        <Ionicons
          name={isFavorite(movie.id) ? "heart" : "heart-outline"}
          size={20}
          color={isFavorite(movie.id) ? "#ff6b6b" : "#fff"}
        />
      </TouchableOpacity>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    minWidth: 150,
    maxWidth: 260,
    marginHorizontal: 4,
    marginVertical: 8,
    borderRadius: 12,
    backgroundColor: "#1c1c1c",
    overflow: "hidden",
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 6,
    ...(Platform.OS === 'web' ? { cursor: 'pointer' } : {}),
  },
  image: {
    width: '100%',
    height: 240,
    justifyContent: 'flex-end',
  },
  imageStyle: {
    resizeMode: 'cover',
  },
  overlay: {
    width: '100%',
    paddingHorizontal: 8,
    paddingVertical: 10,
    backgroundColor: 'rgba(0,0,0,0.45)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  infoLeft: {
    flex: 1,
    paddingRight: 8,
  },
  title: {
    fontWeight: "bold",
    color: "#fff",
    fontSize: 14,
  },
  year: {
    color: "#aaa",
    fontSize: 12,
    marginTop: 2,
  },
  favoriteButton: {
    position: "absolute",
    top: 8,
    right: 8,
    backgroundColor: "rgba(0,0,0,0.55)",
    borderRadius: 20,
    padding: 4,
  },
  rating: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    paddingHorizontal: 6,
    paddingVertical: 4,
    borderRadius: 12,
  },
  ratingText: {
    color: '#fff',
    marginLeft: 6,
    fontWeight: '600',
    fontSize: 13,
  },
  placeholder: {
    position: 'absolute',
    alignSelf: 'center',
    top: 64,
    alignItems: 'center',
  },
  placeholderText: {
    color: '#666',
    marginTop: 6,
    fontSize: 12,
  },
});
