import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useTheme } from "../context/ThemeContext";

export default function NavBar() {
  const navigation = useNavigation();
  const { theme } = useTheme();

  return (
    <View style={[styles.navbar, { backgroundColor: theme.surface, borderBottomColor: theme.primary }]}>
      <View style={styles.logoContainer}>
        <Ionicons name="film" size={24} color={theme.primary} />
        <Text style={[styles.title, { color: theme.text }]}>Movie Explorer</Text>
      </View>
      
      <View style={styles.navLinks}>
        <TouchableOpacity 
          style={styles.link}
          onPress={() => navigation.navigate("Home")}
        >
          <Ionicons name="home" size={20} color={theme.primary} />
          <Text style={[styles.linkText, { color: theme.primary }]}>Home</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.link}
          onPress={() => navigation.navigate("Favorites")}
        >
          <Ionicons name="heart" size={20} color={theme.primary} />
          <Text style={[styles.linkText, { color: theme.primary }]}>Favoritos</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  navbar: {
    borderBottomWidth: 1,
    paddingHorizontal: 8,
    paddingVertical: 0,
    paddingTop: 0,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    height: 40,
  },
  logoContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 3,
    flex: 1,
  },
  title: {
    fontSize: 12,
    fontWeight: "700",
  },
  navLinks: {
    flexDirection: "row",
    gap: 6,
  },
  link: {
    flexDirection: "row",
    alignItems: "center",
    gap: 1,
    paddingHorizontal: 4,
    paddingVertical: 2,
    borderRadius: 2,
  },
  linkText: {
    fontWeight: "600",
    fontSize: 9,
  },
});
